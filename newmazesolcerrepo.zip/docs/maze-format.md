# Maze File Format

Maze files are plain text (`.txt`) files where each line represents a row of the maze.

## Characters

| Character | Meaning     |
|-----------|-------------|
| `#`       | Wall        |
| ` `       | Open path   |
| `S`       | Start point |
| `E`       | End point   |

## Rules

- The maze must contain exactly one `S` and one `E`.
- Rows may have different lengths; shorter rows are padded with walls.
- The outer border is typically walls to prevent out-of-bounds traversal.

## Example

```
####################
#S  #     #        #
# # # ### # ###### #
# #   #   # #      #
# ##### ### # ######
#       #   #      #
####### # ### #### #
#     # #   #    # #
# ### # ### #### # #
# #   #   #      # #
# # ### # ######## #
# # #   #          #
# # # ### ########E#
# #   #            #
####################
```
