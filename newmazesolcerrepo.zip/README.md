# Maze Solver — BFS & DFS

A maze solving project with a C++ backend algorithm implementation and an interactive browser-based frontend visualizer.

## Project Structure

```
maze-solver/
├── cpp/
│   ├── maze_solver.cpp   # C++ BFS & DFS solver (reads from file)
│   └── maze.txt          # Example maze input
├── frontend/
│   └── index.html        # Interactive visualizer (single file, no build step)
├── docs/
│   └── maze-format.md    # Maze file format specification
└── README.md
```

---

## C++ Solver

### Compile

```bash
g++ -std=c++17 -o maze_solver cpp/maze_solver.cpp
```

### Run

```bash
./maze_solver cpp/maze.txt
```

### Maze File Format

| Character | Meaning |
|-----------|---------|
| `#`       | Wall    |
| ` `       | Open path |
| `S`       | Start   |
| `E`       | End     |

**Example (`maze.txt`):**
```
####################
#S  #     #        #
# # # ### # ###### #
#     #   # #      #
####################E#
```

### Output

- Prints original maze
- Shows BFS path (marked `.`) — always finds the **shortest** path
- Shows DFS path (marked `*`) — finds **a** path (not necessarily shortest)
- Prints step count comparison

---

## Frontend Visualizer

No build step required — just open in a browser.

```bash
open frontend/index.html
# or
python3 -m http.server 8080   # then visit http://localhost:8080/frontend/
```

### Features

- Draw walls, open paths, start, and end by clicking/dragging
- Import a text maze (`#`, space, `S`, `E` format)
- Export current grid as text
- Generate a random maze instantly
- Animate BFS and DFS solving step-by-step
- Visual path comparison with step counts and visited-cell counts

---

## Algorithms

### BFS (Breadth-First Search)
- Uses a **queue**
- Explores level by level outward from start
- **Guarantees the shortest path**
- Visits more cells on average

### DFS (Depth-First Search)
- Uses a **stack**
- Explores as deep as possible before backtracking
- Does **not** guarantee shortest path
- Generally visits fewer cells but may find longer routes

---

## License

MIT
